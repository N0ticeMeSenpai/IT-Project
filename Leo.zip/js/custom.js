function myFunction() {
    var x = document.getElementById("myMonth").value;
    document.getElementById("demo").innerHTML = x;
}