<?php  
include 'delinquentFunction.php';
?>

<!DOCTYPE html>
<html>
<head>
    <link rel="stylesheet" href="css/w3.css">
    <link rel="stylesheet" type="text/css" href="css/table.css">
    <link rel="stylesheet" type="text/css" href="css/modal.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/notification.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min2.css">
    <link rel="stylesheet" type="text/css" href="css/navigation.css">
    <link rel="stylesheet" type="text/css" href="css/dashboard.css">
    <script src="js/bootstrap.min.js"></script>
    <script src="js/jquery.min.js"></script>

    <title>List of Delinquents</title>

</head>

<body>
    <div class="container-fluid no-padding">
        <div class="topnav">
            <div class="topnav-right">
                <a href="index.html">Home</a>
                <a href="ClientAdd.html">Add a Client</a>
                <a href="OFListOfRegisteredClient.php" class="active">List of Registered Client</a>
                <a href="SummaryOfBookings.html">Summary of Bookings</a>
                <a href="SORActiveAccount.html">Summary of Receivables</a>
                <a href="ARMovingAccount.html">Aging of Receivables</a>
                <a href="DelinquentReport.html">Delinquents Reports</a>
            </div>
        </div>
        <div class="container">

            <h2 class="p-5 text-center">List of Delinquents</h2>
            <hr>
            <form action="SearchDelinquents.php" method="post">
                <div class="pad-2" id="custom-search-input">
                    <div class="input-group col-md-12">
                        <input type="text" name="searchDelinquents" class="  search-query form-control" placeholder="Search" id="myInput">
                        <span class="input-group-btn">
                            <input class="btn btn-success" type="submit" name="submit-delinquents" value="Search">
                        </span>
                    </div>
                </div>
            </form>


            <br><br>

            <table class="table">
                <thead class="text-white">
                    <tr>
                        <th class="my-bg text-white">Account Name</th>
                        <th class="my-bg text-white" >Co Borrower</th>
                        <th class="my-bg text-white">Balance</th>
                        <th class="my-bg text-white" >Date</th>
                    </tr>
                </thead>
                <?php 
                    echo getDelinquent();

                ?>
            </table>
        </div>
    </div>
    <script type="text/javascript" src="js/Table.js"></script>
    <script type="text/javascript" src="js/modal.js"></script>
    <script type="text/javascript" src="js/custom.js"></script>
</body>

</html>
