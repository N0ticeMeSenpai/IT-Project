<?php
  include 'notification_fetch.php'; 
  include 'navigation.php';
?>

<?php
session_start();
//Checking User Logged or Not
if(empty($_SESSION['user'])){
    header('location:Login.php');
}


//timeout after 5 sec
if(isset($_SESSION['user'])) {
    if((time() - $_SESSION['last_time']) > 1800) {
      header("location:logout.php");  
    }
}


//Restrict User or Moderator to Access Admin.php page
if($_SESSION['user']['em_position']=='Operations Manager'){
    header('location:AdminDashboard.php');
}
?>
<?php
    $con = mysqli_connect('127.0.0.1','root','');
    
    if(!$con){
        echo 'Not Connected To Server';
    }
    
    if(!mysqli_select_db($con,'sigma')){
        echo 'Not Selected';
    }
    
    $search = $_POST['search'];
    
    $sql = "SELECT * FROM client WHERE last_name='$search';";
    $result1 = mysqli_query($con,$sql);
    $resultCheck = mysqli_num_rows($result1);
    $ctr = 0;
      
?>

<!DOCTYPE html>
<html>
  <head>
    <link rel="stylesheet" type="text/css" href="css/table.css">
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/modal.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">
    <link rel="stylesheet" type="text/css" href="css/notification.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min2.css">
    <link rel="stylesheet" type="text/css" href="css/navigation.css">
    <link rel="stylesheet" type="text/css" href="css/navigation2.css">
    <link rel="stylesheet" type="text/css" href="css/dashboard.css">
    <link rel="stylesheet" type="text/css" href="css/footer.css">
    <script src="js/bootstrap.min.js"></script>
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.2.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
    <title></title>
  </head>
<body>
<div class="no-padding">
    <nav id="myNavbar" class="navbar nav-color" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <a class="navbar-brand" href="dashboard.php">SIGMA</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
              <?php
                echo navigate_it()
              ?>
                <ul class="nav navbar-nav navbar-right">
                   <li><a href="notification.php">
                              <?php
                              if(count_data() > '0'){
                                echo count_data();
                              }
                             ?>
                            <img src="img/notifications-button.png" width="15px">
                        </a></li>
                  <?php
                    echo navigate_right();

                  ?>
                </ul>
            </div>
        </div>
    </nav>
    <div class="container">
      <h2 class="p-5 text-center">List Of Clients</h2>
        <form action="search.php" method="post">
        <input id="myInput" type="text" placeholder="Search.." name="search"><input type="submit" value="Search">
        </form>    
        <br>
        
        <?php
            if($resultCheck > 0){
                While ($row2 = mysqli_fetch_assoc($result1)){
                       $sql1 = "SELECT * FROM loan where client_id='".$row2['client_id']."';";
                        $result2 = mysqli_query($con,$sql1);
                        $resultCheck2 = mysqli_num_rows($result2);
                        if($resultCheck2 > 0){
                        While ($row1 = mysqli_fetch_assoc($result2)){
                                        $sql2 = "SELECT due_date,remaining_balance FROM payment WHERE loan_id='".$row1['loan_id']."'";
                            
                         //for Late Payment
                        $sqlForLate = "SELECT MIN(payment_id) as `payment_id`,due_date,bi_monthly FROM payment JOIN loan ON payment.loan_id=loan.loan_id WHERE payment.loan_id='".$row1['loan_id']."' && payment_id NOT IN(SELECT payment_id FROM payment_info)";
                        $rowForLate = mysqli_fetch_assoc(mysqli_query($con,$sqlForLate));
                        $payment_id = $rowForLate['payment_id'];
                        $fine = $rowForLate['bi_monthly'] * 0.05;
                        $bi_monthly = $rowForLate['bi_monthly'];
                        if(date("Y-m-d") > $rowForLate['due_date']){
                            $sqlLateUpdate = "INSERT INTO payment_info (fines,payment_id) VALUES ($fine,$payment_id)"; 
                            mysqli_query($con,$sqlLateUpdate);
                             
                            $sqlUpdateBalance = "SELECT due_date FROM payment WHERE loan_id='".$row1['loan_id']."' && payment_id IN (SELECT payment_id FROM payment_info WHERE status='updated');";
                            $resultUpdateBalance = mysqli_query($con,$sqlUpdateBalance);
                            $resultCheckBalance = mysqli_num_rows($resultUpdateBalance);
                            if($resultCheckBalance > 0){
                                While ($rowUpdateBalance = mysqli_fetch_assoc($resultUpdateBalance)){

                                    $sqlUpdate = "UPDATE payment SET remaining_balance=(SELECT (loan_balance+SUM(fines)+SUM(interest)-(SUM(amount_paid))) as remaining_balance FROM (SELECT * FROM payment) AS `payment` JOIN payment_info ON payment_info.payment_id = payment.payment_id JOIN loan ON payment.loan_id=loan.loan_id WHERE due_date <= '".$rowUpdateBalance['due_date']."' && payment.loan_id='".$row1['loan_id']."' && status='updated') WHERE loan_id='".$row1['loan_id']."' && due_date='".$rowUpdateBalance['due_date']."'";

                                     if (!mysqli_query($con,$sqlUpdate)) {
                                    echo "Error: " . mysqli_error($con);

                                    }
                                }
                            }
                        }
                    
            
            ?>
  <div id="modal<?php echo $ctr;?>" class="modal">
    <div class="modal-content">
      <span class="close">&times;</span>
      <form class="text-center" action="payment.php" method="post">
          <input type='hidden' name='loan_id' value='<?php echo $row1['loan_id']; ?>'/>
          <input type='hidden' name='search' value='<?php echo $search; ?>'/>

         <h2 class="p-3">Due Date</h2>
         <select class="i-2" name="choice">

            <?php 
             
             $result4 = mysqli_query($con,$sql2);
             while($row4 = mysqli_fetch_array($result4)):;?>

            <option value="<?php echo $row4[0];?>"><?php echo $row4[0];?></option>

            <?php endwhile;?>

        </select>
        <h2 class="p-3">Date paid</h2>
        <input class="i-2" type="input" name="date" placeholder="Date"><br>
        <h2 class="p-3">Amount paid</h2>
        <input class="i-2" type="input" name="payment" placeholder="Payment"><br>
          <h2 class="p-3">Type of Payment</h2>
        <input class="i-2" type="input" name="payment_type"><br>
          <h2 class="p-3">Remarks</h2>
        <input class="i-2" type="input" name="remarks"><br>
        <div class="py-3 ">
          <input class="b-2" type="submit" value="Submit">
        </div>
      </form>
    </div>

  </div>
    
  <!--For Sick Excuse-->
  <div id="modalSick<?php echo $ctr;?>" class="modal">
    <div class="modal-content">
      <span class="close">&times;</span>
      <form class="text-center" action="sick.php" method="post">
          <input type='hidden' name='loan_id' value='<?php echo $row1['loan_id']; ?>'/>
          <input type='hidden' name='search' value='<?php echo $search; ?>'/>

         <h2 class="p-3">Start</h2>
         <select class="i-2" name="start">

            <?php 
             
             $result4 = mysqli_query($con,$sql2);
             while($row4 = mysqli_fetch_array($result4)):;?>

            <option value="<?php echo $row4[0];?>"><?php echo $row4[0];?></option>

            <?php endwhile;?>

        </select>
        <h2 class="p-3">End</h2>
         <select class="i-2" name="end">

            <?php 
             
             $result4 = mysqli_query($con,$sql2);
             while($row4 = mysqli_fetch_array($result4)):;?>

            <option value="<?php echo $row4[0];?>"><?php echo $row4[0];?></option>

            <?php endwhile;?>

        </select>
        
        <div class="py-3 ">
          <input class="b-2" type="submit" value="Submit">
        </div>
      </form>
    </div>

  </div>
        
        <table class="table">
            <hr>
            <br>
            <p>                           
            <p> Name: <?php echo $row2['first_name'] ,' ', $row2['last_name']; ?>
            <span class="float-right">
            <form method="post" action="restructure.php">
           <input type="hidden" name="loan_idforR" value='<?php echo $row1['loan_id']; ?>' />
           <input type='hidden' name='search' value='<?php echo $search; ?>'/>
           <input type="submit" value="Restructure" />
            </form>    
            </span></p>

            <p>Date Booked: <?php echo $row1['date_booked']; ?> <span>Bi-Monthly Payment: <?php echo $row1['bi_monthly']; ?></span>
            <span class="float-right">Maturity Date: <?php echo $row1['maturity_date']; ?></span></p>
           <thead class="text-white">
            <tr>
              <th class="my-bg">Date</th>
              <th class="my-bg">Check # EW</th>
              <th class="my-bg">Ref/OR#</th>
              <th class="my-bg">Payment</th>
              <th class="my-bg">Interest</th>
              <th class="my-bg">Fines</th>
              <th class="my-bg">Balance</th>
              <th class="my-bg"></th>

            </tr>
          </thead>
            <?php
                $result3 = mysqli_query($con,$sql2);
                $resultCheck1 = mysqli_num_rows($result3);
                if($resultCheck1 > 0){
                    While ($row3 = mysqli_fetch_assoc($result3)){
                        $sqlForPayInfo = "SELECT GROUP_CONCAT(payment_type) as payment_type,GROUP_CONCAT(check_no) as check_no,GROUP_CONCAT(ref_no) as ref_no,SUM(amount_paid) as amount_paid,SUM(interest) as interest,SUM(fines) as fines,GROUP_CONCAT(remarks) as remarks FROM payment_info JOIN payment ON payment.payment_id = payment_info.payment_id WHERE (status ='updated' || status is NULL) && due_date='".$row3['due_date']."'; ";
                        $rowForPayInfo = mysqli_fetch_assoc(mysqli_query($con,$sqlForPayInfo));
                

            ?>
            <tbody id="myTable">
            <tr>
              <td><?php echo $row3['due_date']; ?></td> 
              <td><?php echo $rowForPayInfo['check_no']; ?></td>
              <td><?php echo $rowForPayInfo['ref_no']; ?></td>
              <td><?php echo $rowForPayInfo['amount_paid']; ?></td>
              <td><?php echo $rowForPayInfo['interest']; ?></td>
              <td><?php echo $rowForPayInfo['fines']; ?></td>
              <td><?php echo $row3['remaining_balance'];?></td>

             
            <?php
                    }
                    echo ' <td>
                <button data-modal="modal'.$ctr.'" class="button" style="font-size:24px; border-radius: 10px;">
                <img src="img/money.png" width=20px>  
                </button>
                <button data-modal="modalSick'.$ctr.'" class="button" style="font-size:24px; border-radius: 10px;">
                <img src="img/money.png" width=20px>  
                </button>
              </td>    
            </tr>
            
            </tbody>
            ';
                    $ctr++;

                    
                    }
                        }
                        }
              }
            }else{
                
                 
            ?>
            <table>
           <thead class="text-white">
            <tr>
              <th class="my-bg">Date</th>
              <th class="my-bg">Check # EW</th>
              <th class="my-bg">Ref/OR#</th>
              <th class="my-bg">Payment</th>
              <th class="my-bg">Interest</th>
              <th class="my-bg">Fines</th>
              <th class="my-bg">Balance</th>
              <th class="my-bg">Remarks</th>
              <th class="my-bg">Payment</th>

            </tr>
          </thead>
            </table>
            
            <b> NO CLIENT WITH THAT NAME</b>
            
            <?php
            } 
            ?>

        </table>
    </div>
  </div>

    <script type="text/javascript" src="js/Table.js"></script>
    <script type="text/javascript" src="js/modal.js"></script>
    <script type="text/javascript" src="js/custom.js"></script>
      
<script>
var modalBtns = [...document.querySelectorAll(".button")];
modalBtns.forEach(function(btn){
  btn.onclick = function() {
    var modal = btn.getAttribute('data-modal');
    document.getElementById(modal).style.display = "block";
  }
});

var closeBtns = [...document.querySelectorAll(".close")];
closeBtns.forEach(function(btn){
  btn.onclick = function() {
    var modal = btn.closest('.modal');
    modal.style.display = "none";
  }
});

window.onclick = function(event) {
  if (event.target.className === "modal") {
    event.target.style.display = "none";
  }
}
</script>
      
</body>
</html>
