<?php
    $con = mysqli_connect('127.0.0.1','root','');
    
    if(!$con){
        echo 'Not Connected To Server';
    }
    
    if(!mysqli_select_db($con,'sigma')){
        echo 'Not Selected';
    }

$number = count($_POST["due"]);
$due = mysqli_real_escape_string($con,$_POST['due']['0']);
$loan_id = mysqli_real_escape_string($con,$_POST['loan_id']);
$amount = mysqli_real_escape_string($con,$_POST['amount']);
if($number > 0)
{
	for($i=0; $i<$number; $i++)
	{
		if(trim($_POST["due"][$i] == ''))
		{
                        $number--;
		}else{
            $sql = "INSERT INTO payment(due_date,loan_id) VALUES('".mysqli_real_escape_string($con, $_POST["due"][$i])."',$loan_id)";
            
			if (!mysqli_query($con,$sql)) {
            echo "Error: " . mysqli_error($con);

            }  
        }

	}
   $queryForInterest = "INSERT INTO payment_info(payment_id,interest) VALUES((SELECT payment_id FROM (SELECT * FROM payment) AS `payment` WHERE loan_id='$loan_id' && due_date='$due'),$amount*0.05*($number/2))";
    mysqli_query($con,$queryForInterest);
   $queryforRB = "UPDATE payment SET remaining_balance=(SELECT (loan_balance+SUM(fines)+SUM(interest)-(SUM(amount_paid))) as remaining_balance FROM (SELECT * FROM payment) AS `payment` JOIN payment_info ON payment_info.payment_id = payment.payment_id JOIN loan ON payment.loan_id=loan.loan_id WHERE payment.loan_id='$loan_id') WHERE loan_id='$loan_id' && due_date='$due'";
    mysqli_query($con,$queryforRB);

	echo ($amount*0.05*($number/2));
}
else
{
	echo "Please Enter Due Date";
}

