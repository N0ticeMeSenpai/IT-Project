<?php
$connection =	mysqli_connect('localhost' , 'root' ,'' ,'sigma');

if(isset($_POST['id'])){
	
	$status = $_POST['status'];
	$id = $_POST['id'];

	//  query to update data 
	 
	$result  = mysqli_query($connection , "UPDATE client SET delinquent_status='$status' WHERE client_id='$id'");

	if($result){
		echo 'data updated';
	}

}
?>