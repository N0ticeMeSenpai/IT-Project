<?php


$username = $_POST['username'];
$password = $_POST['password'];
$position = $_POST['position'];


$conn = mysqli_connect('localhost' , 'root' ,'' ,'sigma');

$sql = "INSERT INTO employee (username, password, em_position)
VALUES ('$username', '$password', '$position')";

	$result = mysqli_query($conn, $sql);

	if($result){
        echo "<script>
      window.location.href='../Usermanagement.php';
      </script>";
	}

?>