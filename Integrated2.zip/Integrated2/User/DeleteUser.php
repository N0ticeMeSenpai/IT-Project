<?php 
$conn=mysqli_connect('localhost','root','','sigma');

if(isset($_GET['employee_id'])){
    $employee_id = $_GET['employee_id'];
    $query = mysqli_query($conn, "DELETE FROM employee WHERE employee_id = '$employee_id'");
    
    if($query){
        echo "<script>
              window.location.href='../Usermanagement.php';
              </script>";
    }else{
        echo "<script>alert('Sorry delete query not work!')
                window.location.href='../Usermanagement.php';
              </script>";
    }
}

?>
