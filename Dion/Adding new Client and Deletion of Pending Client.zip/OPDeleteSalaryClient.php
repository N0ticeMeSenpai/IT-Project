<?php 
$conn=mysqli_connect('localhost','root','','sigma');

if(isset($_GET['client_id'])){
    $client_id = $_GET['client_id'];
    $query = mysqli_query($conn, "DELETE co_borrower , occupation , client FROM client
                INNER JOIN
            occupation ON client.client_id = occupation.client_id
                INNER JOIN
            co_borrower ON occupation.co_borrower_id = co_borrower.co_borrower_id
	           WHERE client.client_id = '$client_id' AND loan_type = 'Salary';");
    if($query){
        echo "<script>
              alert('Deletion Complete');
              window.location.href='OPListOfPendingClient.php';
              </script>";
    }else{
        echo "<script>alert('Sorry delete query not work!')</script>";
    }
}

?>
