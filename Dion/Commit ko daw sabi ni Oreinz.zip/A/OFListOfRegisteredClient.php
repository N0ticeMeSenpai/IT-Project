<!DOCTYPE html>
<html>

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">

    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/table.css">
    <link rel="stylesheet" type="text/css" href="css/modal.css">
    <link rel="stylesheet" type="text/css" href="css/navigation2.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">

    <title>List of Registered Client</title>

</head>

<body>
    <div class="container-fluid no-padding">
        <div class="topnav">
            <div class="topnav-right">
                <a href="index.html">Home</a>
                <a href="ClientAdd.html">Add a Client</a>
                <a href="OFListOfRegisteredClient.php" class="active">List of Registered Client</a>
                <a href="SummaryOfBookings.html">Summary of Bookings</a>
                <a href="SORActiveAccount.html">Summary of Receivables</a>
                <a href="ARMovingAccount.html">Aging of Receivables</a>
                <a href="DelinquentReport.html">Delinquents Reports</a>
            </div>
        </div>
        <div class="container">

            <h2 class="p-5 text-center">List of Registered Clients</h2>

            <hr>
            <h3>Salary Account</h3>
            <hr>

            <form action="OFSearchRegisteredSalaryClient.php" method="post">
                <input type="text" name="search" placeholder="Search Client Name">
                <button type="submit" name="submit-search">Search</button>
            </form>
            <br><br>

            <table>
                <thead class="text-white">
                    <tr>
                        <th class="my-bg">First Name</th>
                        <th class="my-bg">Last Name</th>
                        <th class="my-bg">Contact Number</th>
                        <th class="my-bg">Credit Type</th>
                        <th class="my-bg">Bank Address</th>
                        <th class="my-bg">Bank / Institution</th>
                        <th class="my-bg">Loan Balance</th>
                        <th class="my-bg">Date Booked</th>
                        <th class="my-bg">Maturity Date</th>
                    </tr>
                </thead>

                <?php
                    //Connect the database
                    $conn=mysqli_connect('localhost','root','','sigma');

                    // Attempt select query execution
                    $sql = "SELECT 
                                *
                            FROM
                                client
                            INNER JOIN
                                loan ON client.client_id = loan.client_id
                            WHERE
                                loan_type = 'Salary'
                                    AND registered_status = 'Approve';";
                    if($result = mysqli_query($conn, $sql)){
                        if(mysqli_num_rows($result) > 0){
                            while($row = mysqli_fetch_array($result)){

                                echo "<tbody id='myTable'>";
                                echo "<tr>";
                                echo "<td>" .$row['first_name']. "</td>";
                                echo "<td>" .$row['last_name']. "</td>";
                                echo "<td>" .$row['contact_no']. "</td>";
                                echo "<td>" .$row['credit_type']. "</td>";
                                echo "<td>" .$row['address']. "</td>";
                                echo "<td>" .$row['bank_or_institution']. "</td>";
                                echo "<td>" .$row['loan_balance']. "</td>";
                                echo "<td>" .$row['date_booked']. "</td>";
                                echo "<td>" .$row['maturity_date']. "</td>";
                                echo "</tr>";
                            }
                            echo "</tbody>";

                            // Free result set
                            mysqli_free_result($result);
                        } else{
                            echo "<p class='lead'><em>No pending clients were found.</em></p>";
                        }
                    } else{
                        echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
                    }

                    // Close connection
                    mysqli_close($conn);
                    ?>
            </table>

            <hr>
            <h3>Business Account</h3>
            <hr>

            <form action="OFSearchRegisteredBusinessClient.php" method="post">
                <input type="text" name="search" placeholder="Search Client Name">
                <button type="submit" name="submit-search">Search</button>
            </form>
            <br><br>

            <table>
                <thead class="text-white">
                    <tr>
                        <th class="my-bg">First Name</th>
                        <th class="my-bg">Last Name</th>
                        <th class="my-bg">Contact Number</th>
                        <th class="my-bg">Credit Type</th>
                        <th class="my-bg">Bank Address</th>
                        <th class="my-bg">Bank / Institution</th>
                        <th class="my-bg">Loan Balance</th>
                        <th class="my-bg">Date Booked</th>
                        <th class="my-bg">Maturity Date</th>
                    </tr>
                </thead>

                <?php
                    //Connect the database
                    $conn=mysqli_connect('localhost','root','','sigma');

                    // Attempt select query execution
                    $sql = "SELECT 
                                *
                            FROM
                                client
                            INNER JOIN
                                loan ON client.client_id = loan.client_id
                            WHERE
                                loan_type = 'Business'
                                    AND registered_status = 'Approve';";
                    if($result = mysqli_query($conn, $sql)){
                        if(mysqli_num_rows($result) > 0){
                            while($row = mysqli_fetch_array($result)){

                                echo "<tbody id='myTable'>";
                                echo "<tr>";
                                echo "<td>" .$row['first_name']. "</td>";
                                echo "<td>" .$row['last_name']. "</td>";
                                echo "<td>" .$row['contact_no']. "</td>";
                                echo "<td>" .$row['credit_type']. "</td>";
                                echo "<td>" .$row['address']. "</td>";
                                echo "<td>" .$row['bank_or_institution']. "</td>";
                                echo "<td>" .$row['loan_balance']. "</td>";
                                echo "<td>" .$row['date_booked']. "</td>";
                                echo "<td>" .$row['maturity_date']. "</td>";
                                echo "</tr>";
                            }
                            echo "</tbody>";

                            // Free result set
                            mysqli_free_result($result);
                        } else{
                            echo "<p class='lead'><em>No pending clients were found.</em></p>";
                        }
                    } else{
                        echo "ERROR: Could not able to execute $sql. " . mysqli_error($conn);
                    }

                    // Close connection
                    mysqli_close($conn);
                    ?>

            </table>
        </div>
    </div>

    <script type="text/javascript" src="js/Table.js"></script>
    <script type="text/javascript" src="js/modal.js"></script>
    <script type="text/javascript" src="js/custom.js"></script>
</body>

</html>
