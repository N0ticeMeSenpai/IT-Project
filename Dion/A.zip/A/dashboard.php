<?php
  include 'notification_fetch.php'; 
?>
<?php
session_start();
//Checking User Logged or Not
if(empty($_SESSION['user'])){
    header('location:Login.php');
}
//Restrict User or Moderator to Access Admin.php page
if($_SESSION['user']['em_position']=='Operations Manager'){
    header('location:AdminDashboard.php');
}
?>

<!DOCTYPE html>
<html>
<head>
	<link rel="stylesheet" type="text/css" href="css/custom.css">
	<link rel="stylesheet" type="text/css" href="css/notification.css">
	<link rel="stylesheet" type="text/css" href="css/bootstrap.min2.css">
	<link rel="stylesheet" type="text/css" href="css/navigation.css">
	<link rel="stylesheet" type="text/css" href="css/dashboard.css">
	<link rel="stylesheet" type="text/css" href="//netdna.bootstrapcdn.com/font-awesome/4.0.3/css/font-awesome.min.css">
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<title></title>
</head>
<body>
<div class="no-padding">
    <nav id="myNavbar" class="navbar nav-color" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <a class="navbar-brand" href="dashboard.php">SIGMA</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="notification.php">
                              <?php
                              if(count_data() > '0'){
                                echo count_data();
                              }
                             ?>
                            Notification
                        </a></li>
                    <li class="dropdown">
                        <a href="#" data-toggle="dropdown" class="dropdown-toggle">Summary of Receivable <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="SORActiveAccount.php">Active Account</a></li>
                            <li><a href="SORActiveDelinquentAccount.php">Active Deliquent</a></li>
                            <li><a href="SORActiveLegalAccount.php">Active Legal Account</a></li>
                            <li><a href="SORDeliquentAccount.php">Deliquent Account</a></li>
                            <li><a href="SummaryOfBookings">Summary of Bookings</a></li>
                        </ul>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                  <li><a href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>
	<div class="container pad-1">
	  <div class="row">
	    <div class="col-lg-6">
	      <div class="circle-tile ">
	        <div class="circle-tile-content mygreen">
	          <div class="circle-tile-description text-faded">Number of Delinquent</div>
	          <div class="circle-tile-number text-faded ">
	          	<?php
	          	echo count_delinquent() 
	          	?>
	          </div>
	          <a class="circle-tile-footer" href="#">More Info<i class="fa fa-chevron-circle-right"></i></a>
	        </div>
	      </div>
	    </div>
	    <div class="col-lg-6">
	      <div class="circle-tile ">
	        <div class="circle-tile-content mygreen">
	          <div class="circle-tile-description text-faded">Number of active Client</div>
	          <div class="circle-tile-number text-faded ">
	          	<?php
	          	echo count_ActiveClient() 
	          	?>	
	          </div>
	          <a class="circle-tile-footer" href="#">More Info<i class="fa fa-chevron-circle-right"></i></a>
	        </div>
	      </div>
	    </div>
	  </div>
	  <div class="row">
	  	<div class="col pt-3">
		    <div class="mq-panel-wrapper">
				<div class="mq-panel-header">
				    <h3>Notification</h3>
				</div>
				
				<div class="mq-panel-body">
		           <?php
	          			echo dashboard_notification() 
	          		?>	
		        </div>
		    </div>
	    </div>
	  </div>
	</div>
</div>
</body>
</html>