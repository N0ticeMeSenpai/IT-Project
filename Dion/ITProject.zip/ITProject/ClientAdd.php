<!DOCTYPE html>
<html lang="en">

<head>
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">

    <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/table.css">
    <link rel="stylesheet" type="text/css" href="css/modal.css">
    <link rel="stylesheet" type="text/css" href="css/navigation2.css">
    <link rel="stylesheet" type="text/css" href="css/style.css">

    <title>Add a Client</title>

    <!-- OJT PROJECT CSS-->
    <!-- Bootstrap core CSS -->
    <link href="assets/css/bootstrap.css" rel="stylesheet">
    <!--external css-->
    <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />

    <!-- Custom styles for this template -->
    <link href="assets/css/style.css" rel="stylesheet">
    <link href="assets/css/style-responsive.css" rel="stylesheet">
</head>

<body>
    <div var extracted1="loan_type" ; class="container-fluid no-padding">
        <div class="topnav">
            <div class="topnav-right">
                <a href="index.html">Home</a>
                <a href="ClientAdd.html">Add a Client</a>
                <a href="OFListOfRegisteredClient.php" class="active">List of Registered Client</a>
                <a href="SummaryOfBookings.html">Summary of Bookings</a>
                <a href="SORActiveAccount.html">Summary of Receivables</a>
                <a href="ARMovingAccount.html">Aging of Receivables</a>
                <a href="DelinquentReport.html">Delinquents Reports</a>
            </div>
        </div>
    </div>

    <!--main content start-->
    <section id="main-content">
        <section class="wrapper site-min-height">

            <!-- BASIC FORM ELELEMNTS -->
            <div class="row mt">
                <div class="col-lg-12">
                    <div class="form-panel">
                        <h4 class="mb"><i class="fa fa-angle-right"></i>Loan Application Form</h4>

                        <form class="form-horizontal style-form" action="ClientAddAction.php" method="POST">
                            <center>
                                <h4 class="mb"><i class="fa fa-angle-right"></i>
                                    Client Personal Information
                                </h4>
                            </center>

                            <div class="form-group">
                                <label class="col-sm-2 col-sm-2 control-label">First Name</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="first_name" id="first_name" pattern="{1,}" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 col-sm-2 control-label">Last Name</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="last_name" id="last_name" pattern="{1,}" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 col-sm-2 control-label">Name of Spouse</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="name_of_spouse" id="name_of_spouse" pattern="{1,}" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 col-sm-2 control-label">Present Address</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="present_address" id="present_address" pattern="{1,}" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 col-sm-2 control-label">Contact Number</label>
                                <div class="col-sm-10">
                                    <input type="number" class="form-control" name="contact_no" id="contact_no" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 col-sm-2 control-label">Requested Amount</label>
                                <div class="col-sm-10">
                                    <input type="number" class="form-control" name="requested_amount" id="requested_amount" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 col-sm-2 control-label">Registered Date</label>
                                <div class="col-sm-10">
                                    <input type="date" class="form-control" name="registered_date" id="registered_date" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 col-sm-2 control-label">Loan Type</label>
                                <div class="col-sm-10">
                                    <select name="loan_type" class="form-control selectpicker">
                                        <option>Business</option>
                                        <option>Salary</option>
                                    </select>
                                </div>
                            </div>

                            <center>
                                <h4 class="mb"><i class="fa fa-angle-right"></i>
                                    Client Work Information
                                </h4>
                            </center>

                            <div class="form-group">
                                <label class="col-sm-2 col-sm-2 control-label">Business Address</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="business_address" id="business_address" pattern="{1,}" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 col-sm-2 control-label">Name of Firm</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="name_of_firm" id="name_of_firm" pattern="{1,}" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 col-sm-2 control-label">Employment</label>
                                <div class="col-sm-10">
                                    <select name="employment" class="form-control selectpicker">
                                        <option>Employed</option>
                                        <option>Own Business</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 col-sm-2 control-label">Position</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="position" id="position" pattern="{1,}" required>
                                </div>
                            </div>

                            <center>
                                <h4 class="mb"><i class="fa fa-angle-right"></i>
                                    Co Borrower Personal Information
                                </h4>
                            </center>

                            <div class="form-group">
                                <label class="col-sm-2 col-sm-2 control-label">ID Number</label>
                                <div class="col-sm-10">
                                    <input type="number" class="form-control" name="co_borrower_id" id="co_borrower_id" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 col-sm-2 control-label">First Name</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="co_first_name" id="co_first_name" pattern="{1,}" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 col-sm-2 control-label">Last Name</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="co_last_name" id="co_last_name" pattern="{1,}" required>
                                </div>
                            </div>


                            <div class="form-group">
                                <label class="col-sm-2 col-sm-2 control-label">Contact Number</label>
                                <div class="col-sm-10">
                                    <input type="number" class="form-control" name="co_contact_no" id="co_contact_no" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 col-sm-2 control-label">Address</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="co_address" id="co_address" pattern="{1,}" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 col-sm-2 control-label">Relationship to the Client</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="related_client" id="related_client" pattern="{1,}" required>
                                </div>
                            </div>

                            <center>
                                <h4 class="mb"><i class="fa fa-angle-right"></i>
                                    Co Borrower Work Information
                                </h4>
                            </center>

                            <div class="form-group">
                                <label class="col-sm-2 col-sm-2 control-label">Business Address</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="co_business_address" id="co_business_address" pattern="{1,}" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 col-sm-2 control-label">Name of Firm</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="co_name_of_firm" id="co_name_of_firm" pattern="{1,}" required>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 col-sm-2 control-label">Employment</label>
                                <div class="col-sm-10">
                                    <select name="co_employment" class="form-control selectpicker">
                                        <option>Employed</option>
                                        <option>Own Business</option>
                                    </select>
                                </div>
                            </div>

                            <div class="form-group">
                                <label class="col-sm-2 col-sm-2 control-label">Position</label>
                                <div class="col-sm-10">
                                    <input type="text" class="form-control" name="co_position" id="co_position" pattern="{1,}" required>
                                </div>
                            </div>


                            <button class="btn btn-primary btn-lg btn-block" type="submit" name="create">CREATE</button>

                        </form>

                    </div>
                </div>
            </div>

        </section>
    </section>

    <!-- js placed at the end of the document so the pages load faster -->
    <script src="assets/js/jquery.js"></script>
    <script src="assets/js/bootstrap.min.js"></script>
    <script src="assets/js/jquery-ui-1.9.2.custom.min.js"></script>
    <script src="assets/js/jquery.ui.touch-punch.min.js"></script>
    <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
    <script src="assets/js/jquery.scrollTo.min.js"></script>
    <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>


    <!--common script for all pages-->
    <script src="assets/js/common-scripts.js"></script>

    <!--script for this page-->

    <script>
        //custom select box

        $(function() {
            $('select.styled').customSelect();
        });

    </script>

</body>

</html>
