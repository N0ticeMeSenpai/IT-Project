<!DOCTYPE html>
<html>

<head>
    <title></title>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
    <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
    <link rel="stylesheet" type="text/css" href="css/custom.css">
    <link rel="stylesheet" type="text/css" href="css/clientinfo.css">
</head>

<body>
    <div class="container-fluid">
        <div class="container">
            <div class="toppad">
                <div class="panel panel-info">

                    <?php
                            //Connect to the database
                            $conn=mysqli_connect('localhost','root','','sigma_database');

                            // Attempt select query execution
                    
                    <div class="panel-heading">
                        <h3 class="panel-title pt-5">Client name</h3>
                    </div>

                    <div class="panel-body">
                        <div class="row">

                            <div class="col-md-3 col-lg-3 " align="center">
                                <img alt="User Pic" src="http://babyinfoforyou.com/wp-content/uploads/2014/10/avatar-300x300.png" class="img-circle img-responsive">
                            </div>

                            <div class=" col-md-9 col-lg-9 ">
                                <table class="table table-user-information">
                                    <tbody>
                                        <tr>
                                            <td>Job Description</td>
                                            <td>Programming</td>
                                        </tr>

                                        <tr>
                                            <td>Date of Birth</td>
                                            <td>06/23/2013</td>
                                        </tr>

                                        <tr>
                                            <td>Citizen Status</td>
                                            <td>01/24/1988</td>
                                        </tr>

                                        <tr>
                                            <td>Gender</td>
                                            <td>Female</td>
                                        </tr>

                                        <tr>
                                            <td>Home Address</td>
                                            <td>Kathmandu,Nepal</td>
                                        </tr>

                                        <tr>
                                            <td>Email</td>
                                            <td><a href="mailto:info@support.com">info@support.com</a></td>
                                        </tr>

                                        <tr>
                                            <td>Source of income</td>
                                        </tr>

                                        <tr>
                                            <td>Monthly Income</td>
                                        </tr>

                                        <tr>
                                            <td>Age</td>
                                            <td>22 yrs. old</td>
                                        </tr>

                                        <tr>
                                            <td>Phone Number</td>
                                            <td>123-4567-890(Landline)<br><br>555-4567-890(Mobile)
                                        </tr>

                                        <tr>
                                            <td>Phone Number</td>
                                            <td>123-4567-890(Landline)<br><br>555-4567-890(Mobile)
                                        </tr>

                                    </tbody>
                                </table>
                                    
                            </div>
                            
                        </div>
                    </div>

                </div>
            </div>
        </div>
    </div>

</body>

</html>
