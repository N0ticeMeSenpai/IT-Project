<!DOCTYPE html>
<html lang="en">

    <head>
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
        <link rel="stylesheet" href="https://use.fontawesome.com/releases/v5.5.0/css/all.css" integrity="sha384-B4dIYHKNBt8Bc12p+WXckhzcICo0wtJAoU8YZTY5qE0Id1GSseTk6S+L3BlXeVIU" crossorigin="anonymous">

        <link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
        <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css">
        <link rel="stylesheet" type="text/css" href="css/bootstrap.css">
        <link rel="stylesheet" type="text/css" href="css/custom.css">
        <link rel="stylesheet" type="text/css" href="css/table.css">
        <link rel="stylesheet" type="text/css" href="css/modal.css">
        <link rel="stylesheet" type="text/css" href="css/navigation2.css">
        <link rel="stylesheet" type="text/css" href="css/style.css">

        <title>Loaning a Client</title>

        <!-- OJT PROJECT CSS-->
        <!-- Bootstrap core CSS -->
        <link href="assets/css/bootstrap.css" rel="stylesheet">
        <!--external css-->
        <link href="assets/font-awesome/css/font-awesome.css" rel="stylesheet" />

        <!-- Custom styles for this template -->
        <link href="assets/css/style.css" rel="stylesheet">
        <link href="assets/css/style-responsive.css" rel="stylesheet">
    </head>

    <body>
        <div var extracted1="loan_type" ; class="container-fluid no-padding">
            <div class="topnav">
                <div class="topnav-right">
                    <a href="index.html">Home</a>
                    <a href="ClientAdd.html">Add a Client</a>
                    <a href="OFListOfRegisteredClient.php" class="active">List of Registered Client</a>
                    <a href="SummaryOfBookings.html">Summary of Bookings</a>
                    <a href="SORActiveAccount.html">Summary of Receivables</a>
                    <a href="ARMovingAccount.html">Aging of Receivables</a>
                    <a href="DelinquentReport.html">Delinquents Reports</a>
                </div>
            </div>
        </div>

        <!--main content start-->
        <section id="main-content">
            <section class="wrapper site-min-height">

                <!-- BASIC FORM ELELEMNTS -->
                <div class="row mt">
                    <div class="col-lg-12">
                        <div class="form-panel">
                            <h4 class="mb"><i class="fa fa-angle-right"></i>Loan Application Form</h4>

                            <form class="form-horizontal style-form" action="ClientLoanAction.php" method="POST">
                                <center>
                                    <h4 class="mb"><i class="fa fa-angle-right"></i>
                                        Pakimodal daw sabi ni Timothy pag iiclick ung approve na kay Jasper ung update Approve o Denied ung client na code.
                                    </h4>
                                </center>

                                <div class="form-group">
                                    <label class="col-sm-2 col-sm-2 control-label">Loan Balance</label>
                                    <div class="col-sm-10">
                                        <input type="number" class="form-control" name="loan_balance" id="loan_balance" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label class="col-sm-2 col-sm-2 control-label">Date Booked</label>
                                    <div class="col-sm-10">
                                        <input type="date" class="form-control" name="date_booked" id="date_booked" required>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="col-sm-2 col-sm-2 control-label">Maturity Date</label>
                                    <div class="col-sm-10">
                                        <input type="date" class="form-control" name="maturity_date" id="maturity_date" required>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="col-sm-2 col-sm-2 control-label">Bi Monthly</label>
                                    <div class="col-sm-10">
                                        <input type="number" class="form-control" name="bi_monthly" id="bi_monthly" required>
                                    </div>
                                </div>
                                
                                <div class="form-group">
                                    <label class="col-sm-2 col-sm-2 control-label">Due Date</label>
                                    <div class="col-sm-10">
                                        <input type="date" class="form-control" name="due_date" id="due_date" required>
                                    </div>
                                </div>
                                
                                <button class="btn btn-primary btn-lg btn-block" type="submit" name="create">CREATE</button>

                            </form>

                        </div>
                    </div>
                </div>

            </section>
        </section>

        <!-- js placed at the end of the document so the pages load faster -->
        <script src="assets/js/jquery.js"></script>
        <script src="assets/js/bootstrap.min.js"></script>
        <script src="assets/js/jquery-ui-1.9.2.custom.min.js"></script>
        <script src="assets/js/jquery.ui.touch-punch.min.js"></script>
        <script class="include" type="text/javascript" src="assets/js/jquery.dcjqaccordion.2.7.js"></script>
        <script src="assets/js/jquery.scrollTo.min.js"></script>
        <script src="assets/js/jquery.nicescroll.js" type="text/javascript"></script>


        <!--common script for all pages-->
        <script src="assets/js/common-scripts.js"></script>

        <!--script for this page-->

        <script>
            //custom select box

            $(function() {
                $('select.styled').customSelect();
            });

        </script>

    </body>

</html>
