<?php
//Connect the database
$conn=mysqli_connect('localhost','root','','sigma');
session_start();

if(isset($_POST['create'])){
    //Loan Table
    $loan_balance = mysqli_real_escape_string($conn, $_POST['loan_balance']);
    $date_booked = mysqli_real_escape_string($conn, $_POST['date_booked']);
    $maturity_date = mysqli_real_escape_string($conn, $_POST['maturity_date']);
    $bi_monthly = mysqli_real_escape_string($conn, $_POST['bi_monthly']);

    //Payment Table
    $due_date = mysqli_real_escape_string($conn, $_POST['due_date']);
    
    $sql1="INSERT INTO loan (loan_balance,date_booked,maturity_date,client_id,bi_monthly) 
                     VALUES ('$loan_balance','$date_booked','$maturity_date',(SELECT MAX(client_id) AS client_id FROM client),'$bi_monthly');";

    $sql2="INSERT INTO payment (due_date,loan_id,client_id)
		                VALUES ('$due_date',(SELECT MAX(loan_id) AS loan_id FROM loan),(SELECT MAX(client_id) AS client_id FROM client));";
    
    $Clientloan1 = mysqli_query($conn, $sql1);
    $Clientloan2 = mysqli_query($conn, $sql2);
    echo "<script>
            alert('Adding a loan for a Client Success');
            window.location.href='OPListOfPendingClient.php';
          </script>";
}
?>
