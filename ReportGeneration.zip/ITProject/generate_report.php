<?php

 function fetch_data()  
 {  
      $output = '';  
      $conn = mysqli_connect("localhost", "root", "", "tut");  
      $sql = "SELECT * FROM pdf_export ORDER BY id ASC";  
      $result = mysqli_query($conn, $sql);  
      
      while($row = mysqli_fetch_array($result))  
      {       
      $output .= 
                  '
                  <tr>  
                      <td>'.$row["name"].'</td>  
                      <td>'.$row["age"].'</td>  
                      <td>'.$row["email"].'</td>
                 </tr>';


                  
      }  
      return $output;  
 } 
 ?>