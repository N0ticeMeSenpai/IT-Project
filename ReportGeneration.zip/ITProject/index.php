<?php
  include 'generate_report.php'; 
?>
 <!DOCTYPE html>  
 <html>  
      <head>  
           <title>SoftAOX | Generate HTML Table Data To PDF From MySQL Database Using TCPDF In PHP</title>  
           <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.6/css/bootstrap.min.css" />            
      </head>  
      <body>  
           <br />
           <div class="container"> 
                <div class="table-responsive">  
                	<div class="col-md-12" align="right">
                	<form method="POST" action="excel.php">
                    <input type="month" name="testDate" >
        						<input type="submit" name="generate_pdf" class="btn btn-success" value="Generate PDF"/>
        					</form> 
                     </div>
                     <br/>
                     <br/>
                     <table class="table table-bordered">  
                          <tr>  
                               <th>Name</th>  
                               <th>Age</th>  
                               <th>Email</th> 
                          </tr>  
                     <?php  
                     echo fetch_data();  
                     ?>  
                     </table>  
                </div>  
           </div>  
      </body>  
 </html>  