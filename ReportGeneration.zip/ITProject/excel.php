<?php

$output = '';  
$conn = mysqli_connect("localhost", "root", "", "tut"); 
$date=$_POST['testDate'];



if(isset($_POST["generate_pdf"]))  
 {
  $month = date("m",strtotime($date));
  $year = date("Y", strtotime($date));
  $sql = "SELECT * FROM pdf_export ORDER BY id ASC";  
  $result = mysqli_query($conn, $sql);  
      
  

  if(mysqli_num_rows($result) > 0)
  {
    $output .= '<table class="table" bordered="1"
                    <tr>
                        <th>Name</th>
                        <th>Age</th>
                        <th>Email</th>
                    </tr>';

      while ($row = mysqli_fetch_array($result))
      {

      	if ($month == date("m",strtotime($row["date"])) && $year == date("Y",strtotime($row["date"]))){
	        $output .='<tr>
	                      <td>'.$row["name"].'</td>  
	                      <td>'.$row["age"].'</td>  
	                      <td>'.$row["email"].'</td>
	                  </tr>';

      	}
      }
      $output .= '</table>';
      header("Content-Type:application/xls");
      header("Content-Disposition: attachment; filename=download.xls");
      echo $output;


  }

 }
  ?>