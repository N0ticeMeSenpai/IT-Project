-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: sigma
-- ------------------------------------------------------
-- Server version	5.7.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client` (
  `client_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `name_of_spouse` varchar(45) DEFAULT NULL,
  `present_address` varchar(100) NOT NULL,
  `contact_no` varchar(45) NOT NULL,
  `requested_amount` int(11) NOT NULL,
  `registered_status` enum('Pending','Approved','Denied') NOT NULL DEFAULT 'Pending',
  `registered_date` date NOT NULL,
  `loan_type` enum('Salary','Business') DEFAULT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES (1,'Ross','Geller','Rachel','New York','09272620418',50000,'Pending','2018-05-05','Salary'),(2,'Joey','Tribbiani','Tits','New York','09285409313',40000,'Approved','2019-01-02','Salary'),(3,'Barney','Stinson','Robin','New Jersey','09415256923',60000,'Denied','2018-03-03','Business'),(4,'Ted','Mosby','Tracy','New Jersey','09315261234',35000,'Pending','2019-01-01','Salary'),(5,'Chandler','Bing','Monica','New York','09256231623',30000,'Approved','2018-03-03','Business'),(6,'Oreinz','Kasilag','Dion','Philippines','09312312312',30000,'Denied','2018-03-04','Salary'),(7,'Bugs','Bunny','Lola','United States','09231251231',40000,'Pending','2019-02-02','Business'),(8,'Brian','Oconner','Miya','United States','09231252368',69000,'Approved','2018-03-08','Business'),(9,'Dominic','Toretto','Letty','United States','09232512312',50000,'Denied','2018-12-24','Business'),(10,'Han','Solo','Leia','Philippines','09231251235',21000,'Pending','2018-11-01','Salary');
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `co_borrower`
--

DROP TABLE IF EXISTS `co_borrower`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `co_borrower` (
  `co_borrower_id` int(11) NOT NULL,
  `co_first_name` varchar(45) NOT NULL,
  `co_last_name` varchar(45) NOT NULL,
  `co_contact_no` varchar(45) NOT NULL,
  `co_address` varchar(100) NOT NULL,
  `related_client` varchar(45) NOT NULL,
  PRIMARY KEY (`co_borrower_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `co_borrower`
--

LOCK TABLES `co_borrower` WRITE;
/*!40000 ALTER TABLE `co_borrower` DISABLE KEYS */;
INSERT INTO `co_borrower` VALUES (1,'Jake','Peralta','09266142109','Brooklyn','Ross'),(2,'Charles','Boyle','09268948231','Baguio','Oreinz'),(3,'Amy','Santiago','09279312512','Pangasinan','Luke'),(4,'Randy','Orton','09356344532','Benguet','Jeffrey'),(5,'John','Cena','09241634234','Tuba','Nikki'),(6,'Roger','Roker','09362362343','Trancoville','Timothy'),(7,'Cong','Velasquez','09261212512','Magsaysay','Jasper'),(8,'Mang','Mengs','09231261234','Rimando','Keyya'),(9,'Luke','Skywalker','09231251234','Bonifacio','Leo'),(10,'Anakin','Skywalker','09263236234','Palengke','Jhester');
/*!40000 ALTER TABLE `co_borrower` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee` (
  `employee_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `em_first_name` varchar(45) NOT NULL,
  `em_last_name` varchar(45) NOT NULL,
  `em_position` enum('Operations Manager','Office Staff') NOT NULL,
  `contact_no` varchar(55) NOT NULL,
  `address` varchar(100) NOT NULL,
  PRIMARY KEY (`employee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (1,'ofstaff','ofstaff','Office','Staff','Office Staff','0924512692','Office Staff House'),(2,'oreinz','oreinz','Operations','Manager','Operations Manager','0912312512','Operations Manager house');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loan`
--

DROP TABLE IF EXISTS `loan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan` (
  `loan_id` int(11) NOT NULL AUTO_INCREMENT,
  `loan_type` enum('Salary','Business') NOT NULL,
  `loan_balance` int(11) NOT NULL,
  `date_booked` date NOT NULL,
  `maturity_date` date NOT NULL,
  `client_id` int(11) NOT NULL,
  `bi_monthly` int(11) NOT NULL,
  PRIMARY KEY (`loan_id`),
  KEY `fk_clientid_loan_idx` (`client_id`),
  CONSTRAINT `fk_clientid_loan` FOREIGN KEY (`client_id`) REFERENCES `client` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan`
--

LOCK TABLES `loan` WRITE;
/*!40000 ALTER TABLE `loan` DISABLE KEYS */;
INSERT INTO `loan` VALUES (1,'Salary',25000,'2017-06-06','2017-09-06',1,69),(2,'Salary',25000,'2019-01-01','2019-03-01',2,69),(3,'Business',30000,'2019-02-02','2019-05-02',3,69),(4,'Salary',40000,'2019-03-03','2019-06-03',4,696),(5,'Business',21000,'2019-01-02','2019-04-02',5,69),(6,'Salary',20000,'2019-01-03','2019-04-03',6,69),(7,'Business',30000,'2019-03-02','2019-06-02',7,69),(8,'Business',40000,'2019-03-01','2019-06-01',8,69),(9,'Business',50000,'2019-01-05','2019-04-01',9,69),(10,'Salary',30000,'2019-01-29','2019-04-29',10,69);
/*!40000 ALTER TABLE `loan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `occupation`
--

DROP TABLE IF EXISTS `occupation`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `occupation` (
  `client_id` int(11) NOT NULL,
  `business_address` varchar(100) NOT NULL,
  `name_of_firm` varchar(60) NOT NULL,
  `employment` enum('Employed','Owner') NOT NULL,
  `position` varchar(60) NOT NULL,
  `co_borrower_id` int(11) NOT NULL,
  `co_business_address` varchar(100) NOT NULL,
  `co_name_of_firm` varchar(60) NOT NULL,
  `co_employment` varchar(45) NOT NULL,
  `co_position` varchar(45) NOT NULL,
  KEY `fk_clientid_occupation_idx` (`client_id`),
  KEY `fk_coborrowerid_occupation_idx` (`co_borrower_id`),
  CONSTRAINT `fk_clientid_occupation` FOREIGN KEY (`client_id`) REFERENCES `client` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_coborrowerid_occupation` FOREIGN KEY (`co_borrower_id`) REFERENCES `co_borrower` (`co_borrower_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `occupation`
--

LOCK TABLES `occupation` WRITE;
/*!40000 ALTER TABLE `occupation` DISABLE KEYS */;
INSERT INTO `occupation` VALUES (1,'Brooklyn','Nine Nine','Employed','Owner',1,'New York','Nine Nine','Employed','Semi Owner'),(2,'awgawgwa','dhsdh','Owner','Owner',2,'asgawgwa','agawgwa','Employed','Semi Owner'),(3,'1qeqwqwt','qwgwegwe','Employed','Owner',2,'agawga','sgagaw','Employed','Semi Owner'),(4,'atwagaw','aerherh','Owner','Owner',3,'asgawga','awgawgaw','Employed','Semi Owner'),(5,'sdfhdher','aerhaerhaer','Employed','Owner',4,'wgawgawgaw','awgawgaw','Employed','Semi Owner'),(6,'sfdhasher','aerhaerhaer','Owner','Owner',1,'gawgaw','awgawgaw','Employed','Semi Owner'),(7,'fhshaerh','haerhaerhae','Owner','Owner',3,'gwagawgaw','awhwahwa','Employed','Semi Owner'),(8,'aerhaehaerh','herahaerha','Employed','Owner',6,'gawgaw','awgawgwa','Employed','Semi Owner'),(9,'earhearhae','reahaerhae','Employed','Owner',7,'dfghdfgh','dfghdfgh','Employed','Semi Owner'),(1,'aerhaerhaer','aerhaerh','Employed','Owner',4,'dgjdfgj','aeeshges','Employed','Semi Owner');
/*!40000 ALTER TABLE `occupation` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `due_date` date DEFAULT NULL,
  `remaining_balance` int(11) DEFAULT NULL,
  `loan_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `fk_loanid_pyment_idx` (`loan_id`),
  KEY `fk_clientid_pyment_idx` (`client_id`),
  CONSTRAINT `fk_clientid_pyment` FOREIGN KEY (`client_id`) REFERENCES `client` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE,
  CONSTRAINT `fk_loanid_pyment` FOREIGN KEY (`loan_id`) REFERENCES `loan` (`loan_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` VALUES (1,'2019-06-07',20000,1,1),(2,'2019-03-05',15000,2,1),(3,'2019-04-03',2000,3,3),(4,'2019-05-24',20000,4,4),(5,'2019-02-24',3000,4,4),(6,'2019-03-02',4000,5,5),(7,'2019-03-05',5000,6,6),(8,'2019-03-05',300,7,7),(9,'2019-04-05',5000,9,9),(10,'2019-05-03',1231,9,9);
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_info`
--

DROP TABLE IF EXISTS `payment_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_info` (
  `payment_id` int(11) NOT NULL,
  `date_paid` date DEFAULT NULL,
  `amount_paid` int(11) DEFAULT NULL,
  `payment_type` varchar(45) DEFAULT NULL,
  `account_number` int(11) DEFAULT NULL,
  `check_no` varchar(45) DEFAULT NULL,
  `ref_no` int(11) DEFAULT NULL,
  `interest` int(11) DEFAULT NULL,
  `fines` int(11) DEFAULT NULL,
  `remarks` varchar(45) DEFAULT NULL,
  KEY `fk_payment_id_pymentinfo_idx` (`payment_id`),
  CONSTRAINT `fk_payment_id_pymentinfo` FOREIGN KEY (`payment_id`) REFERENCES `payment` (`payment_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_info`
--

LOCK TABLES `payment_info` WRITE;
/*!40000 ALTER TABLE `payment_info` DISABLE KEYS */;
INSERT INTO `payment_info` VALUES (1,'2019-07-05',12000,'Cheque',12345,'678891',11111,NULL,NULL,'Paid in cheque'),(2,'2019-03-23',5000,'Cheque',12346,'125123',22222,NULL,NULL,NULL),(3,'2019-03-29',20000,'Cash',12347,'161262',33333,NULL,NULL,NULL),(4,'2019-02-03',3000,'Cheque',12341,'273234',55555,NULL,NULL,NULL),(5,'2019-03-05',2500,'Cheque',12342,'236234',44444,NULL,NULL,NULL),(6,'2019-02-03',7000,'Cash',12348,'457845',66666,NULL,NULL,NULL),(7,'2019-03-02',4800,'Cheque',12353,'323423',77777,NULL,NULL,NULL),(8,'2019-12-12',5000,'Cash',12340,'236234',99999,NULL,NULL,NULL),(9,'2019-07-04',6000,'Cheque',12304,'234234',88888,NULL,NULL,NULL),(10,'2019-01-06',7500,'Cash',12389,'234234',10000,NULL,NULL,NULL);
/*!40000 ALTER TABLE `payment_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rates`
--

DROP TABLE IF EXISTS `rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rates` (
  `rate_id` int(11) NOT NULL,
  `interest` int(11) NOT NULL,
  `service_handling_fee` int(11) NOT NULL,
  `penalty_not_maturity` int(11) NOT NULL,
  `penalty_maturity` int(11) NOT NULL,
  `penalty_maturity_payontime` int(11) NOT NULL,
  PRIMARY KEY (`rate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rates`
--

LOCK TABLES `rates` WRITE;
/*!40000 ALTER TABLE `rates` DISABLE KEYS */;
INSERT INTO `rates` VALUES (1,5,3,5,7,2);
/*!40000 ALTER TABLE `rates` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-03-18 17:10:23
