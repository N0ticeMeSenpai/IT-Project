-- MySQL dump 10.13  Distrib 5.7.17, for Win64 (x86_64)
--
-- Host: localhost    Database: sigma
-- ------------------------------------------------------
-- Server version	5.7.14

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `client`
--

DROP TABLE IF EXISTS `client`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `client` (
  `client_id` int(11) NOT NULL AUTO_INCREMENT,
  `first_name` varchar(45) NOT NULL,
  `middle_name` varchar(45) NOT NULL,
  `last_name` varchar(45) NOT NULL,
  `name_of_spouse` varchar(45) DEFAULT NULL,
  `present_address` varchar(100) NOT NULL,
  `contact_no` varchar(45) NOT NULL,
  `requested_amount` int(11) NOT NULL,
  `registered_status` enum('Pending','Approved','Denied') NOT NULL DEFAULT 'Pending',
  `registered_date` date NOT NULL,
  `loan_type` enum('Salary','Business') DEFAULT NULL,
  `business_address` varchar(100) NOT NULL,
  `name_of_firm` varchar(60) NOT NULL,
  `employment` enum('Employed','Own Business') NOT NULL,
  `position` varchar(60) NOT NULL,
  `date_modified` date NOT NULL,
  `deliquent_status` enum('Active','Inactive','Legal') DEFAULT NULL,
  PRIMARY KEY (`client_id`)
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `client`
--

LOCK TABLES `client` WRITE;
/*!40000 ALTER TABLE `client` DISABLE KEYS */;
INSERT INTO `client` VALUES (1,'Ross','Green','Geller','Rachel','New York','09266142109',50000,'Pending','2018-05-05','Salary','Brooklyn','One One','Own Business','Owner','2019-04-16','Active'),(2,'Joey','Joe','Tribbiani','Phoebe','New York','09266142100',40000,'Approved','2019-01-02','Salary','New York','Two Two','Employed','Owner','2019-04-16','Active'),(3,'Barney','Swarley','Stinson','Robin','New Jersey','09266142101',60000,'Denied','2018-03-03','Business','New Day','Three Three','Own Business','Owner','2019-04-16','Inactive'),(4,'Ted','Smosby','Mosby','Tracy','New Jersey','09266142102',35000,'Pending','2019-01-01','Salary','Manila','Four Four','Employed','Owner','2019-04-16','Inactive'),(5,'Chandler','Bong','Bing','Monica','New York','09266142103',30000,'Approved','2018-03-03','Business','Cebu','Five Five','Own Business','Owner','2019-04-16','Legal'),(6,'Oreinz','Renji','Kasilag','Dion','Philippines','09266142104',30000,'Denied','2018-03-04','Salary','Baguio','Six Six','Employed','Owner','2019-04-16','Legal'),(7,'Bugs','Rabbit','Bunny','Lola','United States','09266142105',40000,'Pending','2019-02-02','Business','Ilocos Norte','Seven Seven','Employed','Owner','2019-04-16','Active'),(8,'Brian','Walker','Oconner','Miya','United States','09266142106',69000,'Approved','2018-03-08','Business','Ilocos Sur','Eight Eight','Own Business','Owner','2019-04-16','Legal'),(9,'Dominic','Diesel','Toretto','Letty','United States','09266142107',50000,'Denied','2018-12-14','Business','La Union','Nine Nine','Employed','Owner','2019-04-16','Active'),(10,'Han','Joe','Solo','Leia','Philippines','09266142108',40000,'Pending','2018-11-01','Salary','Pangasinan','Ten Ten','Own Business','Owner','2019-04-16','Active');
/*!40000 ALTER TABLE `client` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `co_borrower`
--

DROP TABLE IF EXISTS `co_borrower`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `co_borrower` (
  `co_borrower_id` int(11) NOT NULL AUTO_INCREMENT,
  `co_first_name` varchar(45) NOT NULL,
  `co_middle_name` varchar(45) NOT NULL,
  `co_last_name` varchar(45) NOT NULL,
  `co_contact_no` varchar(45) NOT NULL,
  `co_address` varchar(100) NOT NULL,
  `related_client` varchar(45) NOT NULL,
  `co_business_address` varchar(100) NOT NULL,
  `co_name_of_firm` varchar(60) NOT NULL,
  `co_employment` enum('Employed','Own Business') NOT NULL,
  `co_position` varchar(45) NOT NULL,
  `client_id` int(11) NOT NULL,
  PRIMARY KEY (`co_borrower_id`),
  KEY `fk_clientid_coborrower_idx` (`client_id`),
  CONSTRAINT `fk_clientid_coborrower` FOREIGN KEY (`client_id`) REFERENCES `client` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=11 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `co_borrower`
--

LOCK TABLES `co_borrower` WRITE;
/*!40000 ALTER TABLE `co_borrower` DISABLE KEYS */;
INSERT INTO `co_borrower` VALUES (1,'Jake','Anthony','Peralta','09124567893','Brooklyn','Ross','Brooklyn','Nine Nine','Employed','Semi Owner',1),(2,'Charles','Sarge','Boyle','09357234626','Baguio','Oreinz','Baguio','Nine Nine','Employed','Semi Owner',1),(3,'Amy','Farrah','Santiago','09231261241','Pangsinan','Joey','New York','One One','Own Business','Semi Owner',2),(4,'Randy','Penny','Orton','09231261234','Benguet','Ted','Manila','Two Two ','Own Business','Semi Owner',4),(5,'John','Paul','Cena','09346346423','La Trinidad','Barney','New Day','Three Three','Employed','Semi Owner',3),(6,'Daffy','Goofy','Duck','09346234243','La Presa','Ross','Brooklyn','Five Five','Employed','Semi Owner',2),(7,'Ricardo','Roel','Milos','09523523425','John Hay','Chandler','Cebu','Six Six','Own Business','Semi Owner',5),(8,'Dante','Colinas','Gulapa','09623645234','Itogon','Ted','Manila','Seven Seven','Own Business','Semi Owner',4),(9,'Luke','Leia','Skywalker','09347345347','Bonifacio','Brian','Ilocos Sur','Eight Eight','Own Business','Semi Owner',8),(10,'Anakin','Padme','Skywalker','09292452833','Aurora','Bugs','Ilocos Norte','One One','Employed','Semi Owner',7);
/*!40000 ALTER TABLE `co_borrower` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `employee`
--

DROP TABLE IF EXISTS `employee`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `employee` (
  `employee_id` int(11) NOT NULL AUTO_INCREMENT,
  `username` varchar(45) NOT NULL,
  `password` varchar(45) NOT NULL,
  `em_first_name` varchar(45) NOT NULL,
  `em_last_name` varchar(45) NOT NULL,
  `em_position` enum('Operations Manager','Office Staff') NOT NULL,
  `contact_no` varchar(55) NOT NULL,
  `address` varchar(100) NOT NULL,
  `employee_img` longblob NOT NULL,
  PRIMARY KEY (`employee_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `employee`
--

LOCK TABLES `employee` WRITE;
/*!40000 ALTER TABLE `employee` DISABLE KEYS */;
INSERT INTO `employee` VALUES (1,'ofstaff','ofstaff','Office','Staff','Office Staff','0924512692','Office Staff House',''),(2,'oreinz','oreinz','Operations','Manager','Operations Manager','0912312512','Operations Manager house','');
/*!40000 ALTER TABLE `employee` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `loan`
--

DROP TABLE IF EXISTS `loan`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `loan` (
  `loan_id` int(11) NOT NULL AUTO_INCREMENT,
  `loan_balance` int(11) NOT NULL,
  `date_booked` date NOT NULL,
  `maturity_date` date NOT NULL,
  `client_id` int(11) NOT NULL,
  `bi_monthly` int(11) NOT NULL,
  PRIMARY KEY (`loan_id`),
  KEY `fk_clientid_loan_idx` (`client_id`),
  CONSTRAINT `fk_clientid_loan` FOREIGN KEY (`client_id`) REFERENCES `client` (`client_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `loan`
--

LOCK TABLES `loan` WRITE;
/*!40000 ALTER TABLE `loan` DISABLE KEYS */;
INSERT INTO `loan` VALUES (1,50000,'2018-05-05','2018-08-08',1,2500),(2,45000,'2018-05-03','2018-08-03',2,2500),(3,60000,'2018-03-04','2018-06-04',3,2500),(4,75000,'2018-04-03','2018-07-03',4,2500),(5,60000,'2018-02-02','2018-05-05',5,2500),(6,50000,'2018-04-03','2018-07-03',6,2500),(7,40000,'2018-07-05','2018-10-05',7,2500),(8,50000,'2018-12-12','2019-03-12',8,2500),(9,45000,'2018-12-23','2019-03-23',9,2500),(10,45000,'2018-02-04','2018-05-04',10,2500),(11,60000,'2019-01-01','2019-01-02',2,2500);
/*!40000 ALTER TABLE `loan` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment`
--

DROP TABLE IF EXISTS `payment`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment` (
  `payment_id` int(11) NOT NULL AUTO_INCREMENT,
  `due_date` date DEFAULT NULL,
  `remaining_balance` decimal(65,2) DEFAULT NULL,
  `loan_id` int(11) NOT NULL,
  `date_modified` date NOT NULL,
  PRIMARY KEY (`payment_id`),
  KEY `fk_loanid_pyment_idx` (`loan_id`),
  CONSTRAINT `fk_loanid_pyment` FOREIGN KEY (`loan_id`) REFERENCES `loan` (`loan_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=12 DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment`
--

LOCK TABLES `payment` WRITE;
/*!40000 ALTER TABLE `payment` DISABLE KEYS */;
INSERT INTO `payment` VALUES (1,'2019-03-03',300.50,1,'2019-04-16'),(2,'2019-04-02',250.00,2,'2019-04-16'),(3,'2019-03-02',200.00,3,'2019-04-16'),(4,'2018-12-12',450.00,4,'2019-04-16'),(5,'2019-02-02',50.00,4,'2019-04-16'),(6,'2019-03-02',25.25,5,'2019-04-16'),(7,'2019-02-01',25.50,6,'2019-04-16'),(8,'2019-02-03',500.00,7,'2019-04-16'),(9,'2019-01-25',2500.00,8,'2019-04-16'),(10,'2019-02-02',250.50,9,'2019-04-16'),(11,'2019-07-07',3500.00,10,'2019-04-16');
/*!40000 ALTER TABLE `payment` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `payment_info`
--

DROP TABLE IF EXISTS `payment_info`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `payment_info` (
  `payment_id` int(11) NOT NULL,
  `amount_paid` decimal(65,2) DEFAULT NULL,
  `payment_type` enum('Cash','Cheque','Bank Deposit') DEFAULT NULL,
  `date_paid` date DEFAULT NULL,
  `account_number` varchar(45) DEFAULT NULL,
  `check_no` varchar(45) DEFAULT NULL,
  `ref_no` varchar(45) DEFAULT NULL,
  `interest` decimal(65,2) DEFAULT '0.00',
  `fines` decimal(65,2) DEFAULT '0.00',
  `remarks` varchar(45) DEFAULT NULL,
  `status` enum('Pending','Renewed','Updated','Excused') DEFAULT 'Updated',
  KEY `fk_payment_id_pymentinfo_idx` (`payment_id`),
  CONSTRAINT `fk_payment_id_pymentinfo` FOREIGN KEY (`payment_id`) REFERENCES `payment` (`payment_id`) ON DELETE CASCADE ON UPDATE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `payment_info`
--

LOCK TABLES `payment_info` WRITE;
/*!40000 ALTER TABLE `payment_info` DISABLE KEYS */;
INSERT INTO `payment_info` VALUES (1,250.00,'Cash','2018-06-05','123456','111111','2412512',25.00,10.00,'Paid in Cash','Updated'),(1,250.00,'Cheque','2018-06-07','123456','111112','2412513',25.00,10.00,'Paid in Cheque','Updated'),(2,350.00,'Cash','2018-03-04','123457','111113','2412514',25.00,10.00,'Paid in Cash','Updated'),(3,100.00,'Cash','2018-08-05','123458','111114','2415231',25.00,10.00,'Paid in Cash','Updated'),(4,1500.00,'Cash','2018-03-05','123459','111115','2537345',25.00,10.00,'Paid in Cash','Updated'),(4,2500.00,'Cash','2018-05-04','123459','111116','2343473',25.00,10.00,'Paid in Cash','Updated'),(5,2500.00,'Cash','2018-04-05','123460','111117','4534866',25.00,10.00,'Paid in Cash','Updated'),(6,2500.00,'Cash','2019-01-01','123461','111118','3734866',25.00,10.00,'Paid in Cash','Updated'),(7,2500.00,'Cash','2018-03-02','123462','111119','2358564',25.00,10.00,'Paid in Cash','Updated'),(8,15000.00,'Cash','2018-05-03','123463','111110','3584522',25.00,10.00,'Paid in Cash','Updated'),(8,2500.00,'Cash','2019-01-01','123463','111121','5485696',25.00,10.00,'Paid in Cash','Updated'),(9,350.00,'Cash','2019-01-01','123464','111122','2487956',25.00,10.00,'Paid in Cash','Updated'),(10,500.00,'Cash','2018-03-03','123465','111123','1445845',25.00,10.00,'Paid in Cash','Updated');
/*!40000 ALTER TABLE `payment_info` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `rates`
--

DROP TABLE IF EXISTS `rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `rates` (
  `rate_id` int(11) NOT NULL,
  `interest` int(11) NOT NULL,
  `service_handling_fee` int(11) NOT NULL,
  `penalty_not_maturity` int(11) NOT NULL,
  `penalty_maturity` int(11) NOT NULL,
  `penalty_maturity_payontime` int(11) NOT NULL,
  `penalty_lack` int(11) NOT NULL,
  PRIMARY KEY (`rate_id`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `rates`
--

LOCK TABLES `rates` WRITE;
/*!40000 ALTER TABLE `rates` DISABLE KEYS */;
INSERT INTO `rates` VALUES (1,5,3,5,7,2,2);
/*!40000 ALTER TABLE `rates` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2019-04-22 22:53:52
