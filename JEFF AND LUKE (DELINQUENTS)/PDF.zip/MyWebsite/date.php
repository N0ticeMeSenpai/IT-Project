<form action="" method="POST">
	<input type="month" name="testDate"/>
	<input type="submit" name="btn"/>
</form>

<?php

if (isset($_POST['btn'])) {
		$date=$_POST['testDate'];
		$month = date("m",strtotime($date));
		$year = date("Y", strtotime($date));

	if ($month == '4') {
		echo $month, $year;
	}else{
		echo "hello hello";
	}

}

?>

