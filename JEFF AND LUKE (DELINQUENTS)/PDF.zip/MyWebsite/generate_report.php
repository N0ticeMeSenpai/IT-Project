<?php  
 function fetch_data()  
 {  
      $output = '';  
      $conn = mysqli_connect("localhost", "root", "", "tut");  
      $sql = "SELECT * FROM pdf_export ORDER BY id ASC";  
      $result = mysqli_query($conn, $sql);  
      while($row = mysqli_fetch_array($result))  
      {       
      $output .= '<tr>  
                      <td>'.$row["name"].'</td>  
                      <td>'.$row["age"].'</td>  
                      <td>'.$row["email"].'</td>
                 </tr>  
                      ';  
      }  
      return $output;  
 } 
 
  function generate_data()
 {  

    $output = '';  
      $conn = mysqli_connect("localhost", "root", "", "tut");  
      $sql = "SELECT * FROM pdf_export ORDER BY id ASC";  
      $result = mysqli_query($conn, $sql); 
      $date=$_POST['testDate'];
      $month = date("m",strtotime($date));
      $year = date("Y", strtotime($date));
            
            while($row = mysqli_fetch_array($result))  
      {
    if ($month == date("m",strtotime($row["date"])) && $year == date("Y",strtotime($row["date"]))){
      $output .= '<tr>  
                      <td>'.$row["name"].'</td>  
                      <td>'.$row["age"].'</td>  
                      <td>'.$row["email"].'</td> 
                 </tr> ';
    }  
      }  
      return $output;

 }
 ?>