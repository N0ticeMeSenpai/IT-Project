<?php
$connect = mysqli_connect("localhost", "root", "", "sample_delinquent");
$sql = "SELECT * FROM list_of_delinquents";  
$result = mysqli_query($connect, $sql);
?>

<html>
<head>
  <title>List of Delinquents</title>
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css">
  <link rel="stylesheet" href="https://cdn.datatables.net/buttons/1.5.4/css/buttons.dataTables.min.css">
  
</head>
<body>
<script src="https://code.jquery.com/jquery-3.2.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js"></script>

<!-- FILTER OF TABLE -->
<script src="filter.js"></script>

<!-- EXPORT OF TABLE -->
<script src="https://code.jquery.com/jquery-3.3.1.js"></script>
<script src="https://cdn.datatables.net/1.10.19/js/jquery.dataTables.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.4/js/dataTables.buttons.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.4/js/buttons.flash.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jszip/3.1.3/jszip.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/pdfmake.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/pdfmake/0.1.36/vfs_fonts.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.4/js/buttons.html5.min.js"></script>
<script src="https://cdn.datatables.net/buttons/1.5.4/js/buttons.print.min.js"></script>
<script src="export.js"></script>




<div class="container">
<div class="table-responsive">
<p class="display-4 text-center">List of Delinquents</p>



<input class="form-control" id="month" type="text" onkeyup="myMonth()" placeholder="Search..">

<br/>

<table class="table table-hover table-dark" id="example">
  <thead>
    <tr>
      <th scope="col">ID</th>
      <th scope="col">NAME</th>
      <th scope="col">COBORROWER1</th>
      <th scope="col">COBORROWER2</th>
      <th scope="col">BALANCE</th>  
      <th scope="col">DATE (AS OF)</th>
    </tr>
  </thead>
  <tbody>
  <?php
     while($row = mysqli_fetch_array($result))  
     {  
        echo '
       <tr>  
         <td>'.$row["id"].'</td>  
         <td>'.$row["NAME"].'</td>  
         <td>'.$row["COBORROWER1"].'</td>  
         <td>'.$row["COBORROWER2"].'</td>  
         <td>'.$row["BALANCE"].'</td>
         <td>'.$row["DATE(AS OF)"].'</td>
       </tr>  
        ';  
     }
     ?>
  </tbody>
</table>
</div>
</div>

</body>
</html>