<?php
  include 'notification_fetch.php'; 
?>
<!DOCTYPE html>
<html lang="en">
<head>
<title>Example of Bootstrap 3 Dropdowns within a Navbar</title>
<link rel="stylesheet" type="text/css" href="css/custom.css">
<link rel="stylesheet" type="text/css" href="css/notification.css">
<link rel="stylesheet" type="text/css" href="css/bootstrap.min2.css">
<link rel="stylesheet" type="text/css" href="css/navigation.css">
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
</head>
<body>
    <nav id="myNavbar" class="navbar nav-color" role="navigation">
        <div class="container">
            <div class="navbar-header">
                <a class="navbar-brand" href="dashboard.php">SIGMA</a>
            </div>
            <!-- Collect the nav links, forms, and other content for toggling -->
            <div class="collapse navbar-collapse" id="bs-example-navbar-collapse-1">
                <ul class="nav navbar-nav">
                    <li><a href="dashboard.php">Dashboard</a></li>
                    <li><a href="notification.php">
                              <?php
                              if(count_data() > '0'){
                                echo count_data();
                              }
                             ?>
                            Notification
                        </a></li>
                    <li class="dropdown">
                        <a href="#" data-toggle="dropdown" class="dropdown-toggle">Messages <b class="caret"></b></a>
                        <ul class="dropdown-menu">
                            <li><a href="#">Inbox</a></li>
                            <li><a href="#">Drafts</a></li>
                            <li><a href="#">Sent Items</a></li>
                            <li class="divider"></li>
                            <li><a href="#">Trash</a></li>
                        </ul>
                    </li>
                </ul>
                <ul class="nav navbar-nav navbar-right">
                  <li><a href="logout.php">Logout</a></li>
                </ul>
            </div>
        </div>
    </nav>
</body>
</html>                            